# -*- coding: utf-8 -*-
import warnings
warnings.simplefilter("ignore", UserWarning)

import sys
import os
import requests
import json
import pathlib
from datetime import datetime

from requests_ntlm import HttpNtlmAuth

UPDATE_HEADER = {"X-HTTP-Method":"MERGE", "IF-MATCH": "*"}
DELETE_HEADER = {"X-HTTP-Method":"DELETE", "IF-MATCH": "*"}

SHP_OLD_API = 'old'
SHP_NEW_API = '365'
SHP_SQL_API = 'sql'
SHP_SWITCHER = SHP_OLD_API

WORK_SHP = 'https://spp-portal.sigma.sbrf.ru/sites/cc_analytics_requests'
SHP_LIST_SIZE = 4990
CONTEXT_UPDATE_INTERVAL = 2 * 60 #seconds
CERTS_PATHS = os.path.join(pathlib.Path.home(), 'certs')
CERT_PATH = os.path.join(CERTS_PATHS, 'user.nokey.pem')
KEY_PATH = os.path.join(CERTS_PATHS, 'user.key')
ROOT_PATH = os.path.join(CERTS_PATHS, 'root.pem')

def shp_connect(username, password):
	session = requests.Session()
	session.cert = (CERT_PATH, KEY_PATH)
	session.verify = ROOT_PATH
	session.auth = HttpNtlmAuth(username, password)
	return session

def request(session, type_request, custom_url, data = None, headers = None):
	req = requests.Request(type_request,  WORK_SHP + custom_url, data=data, headers=headers)
	prepped = session.prepare_request(req)
	response = session.send(prepped)
	code = str(response.status_code)
	return (code, response)

if __name__ == "__main__":
	session = shp_connect('16522138', 'Lopatin22')
	code, response = request(session, 'GET', "/_api/web/lists/GetByTitle('" + "Users" + "')")
	print(code)
	print(response)