# -*- coding: utf-8 -*-
from datetime import datetime
import os
import json
import sys
import pathlib

from dialog_bot_sdk import interactive_media
from dialog_bot_sdk.entities.Peer import PeerType
from dialog_bot_sdk.bot import DialogBot


# API
DIALOG_CHAT_HOST = 'epbotsandbox.sberchat.sberbank.ru'
# DIALOG_CHAT_HOST = 'webbotsandbox.sberchat.sberbank.ru'
# DIALOG_CHAT_HOST = 'epdev.sberchat.sberbank.ru:443'
DIALOG_CERT_PATH = os.path.join(pathlib.Path.home(), 'certs', 'cab-sa-chat0005.pfx')
DIALOG_CERT_PASSWORD = 'Lopatin1'
# Chat peers
TYPE_PRIVATE_CHAT = PeerType.PEERTYPE_PRIVATE
TYPE_GROUP_CHAT = PeerType.PEERTYPE_GROUP
BOT_PEER_IDS = [
	531842805
]

def connect_bot():
	return DialogBot.get_secure_bot_with_pfx_certificate(
		DIALOG_CHAT_HOST,
		DIALOG_CERT_PATH,
		DIALOG_CERT_PASSWORD,
		verbose=False
	)

def on_msg(params):
	bot.messaging.send_message(params.peer, 'Reply to : ' + str(params.message.text_message.text))

if __name__ == "__main__":

	print(DIALOG_CHAT_HOST, DIALOG_CERT_PATH)
	bot = connect_bot()
	print('Connected')
	bot.messaging.on_message(on_msg)